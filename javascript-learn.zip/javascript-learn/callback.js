function add(a, b, callback) {
  if (typeof a !== "number" || typeof b !== "number") {
    callback(new Error("not a number"),null);
  } else {
    setTimeout(() => {
      let result = a + b;
      callback(null,result);
    });
  }
}

add(2, 2, (err,result1) => {
  if (err) {
    return console.log(err.message);
  }
  console.log(result1);

  add(result1, 2, (err,result2) => {
    if (err) {
      return console.log(err.message);
    }
    console.log(result2);
  });
});
