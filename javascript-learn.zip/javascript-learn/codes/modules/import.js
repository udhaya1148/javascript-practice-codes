// import {add} from './export.js'
// import sub from './export.js'

let value = require('./export.js')
console.log(value.add(2,2));
console.log(value.sub(5,2));