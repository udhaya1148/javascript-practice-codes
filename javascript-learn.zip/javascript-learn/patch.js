async function patch() {
  try {
    let quotes = await fetch("https://mimic-server-api.vercel.app/quotes/38", {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        id: 38,
        author: "A.P.J. Abdul Kalam",
        quote: "The only way to do great work is to love what you do.",
      }),
    });

    if (!quotes.ok) {
      throw new Error("invalid url");
    } else {
      let data = await quotes.text();
      console.log(data);
    }
  } catch (err) {
    console.log(err.message);
  }
}
patch();
