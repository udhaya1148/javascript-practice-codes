// function outer(x){
//     function inner(y){
//         return (x+y);
//     }
//     return inner
// }

// console.log(outer(5)(3))

// let coluser = ((x)=>(y)=> x+y);
// console.log(coluser(5)(3))

