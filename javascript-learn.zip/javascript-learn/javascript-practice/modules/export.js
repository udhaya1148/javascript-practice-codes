// function add(a,b){
//     return a+b;
// }

// export {add};

function sub(a,b){
    return a-b;
}

module.exports = {sub};

// const multi = function(a,b){
//     return a*b;
// }

// export default multi;