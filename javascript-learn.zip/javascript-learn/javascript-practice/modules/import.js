// import {add} from "./export.js"
let subract = require("./export.js")
// import multi from "./export.js"

// console.log(add(2,2));
console.log(subract.sub(5,4));
// console.log(multi(2,2));