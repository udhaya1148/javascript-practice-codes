let message = "I am learning JavaScript";

console.log(message.toUpperCase());
console.log(message.length);
console.log(message.slice(0,4));
console.log(message.includes("JavaScript"));


