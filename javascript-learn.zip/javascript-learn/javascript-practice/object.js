let car = {
    brand: "BMW",
    model: "X5",
    year: 2023
}

car.color="Black";
car.year = 2024;

for(key in car){
    console.log(key +" "+car[key]);
} 


