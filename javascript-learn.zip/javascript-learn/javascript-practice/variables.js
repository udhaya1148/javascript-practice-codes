let name="ram";
let score =99;
let isPassed = true;
const country = "India";

console.log(name);
console.log(score);
console.log(isPassed);
console.log(country);

console.log(typeof name);
console.log(typeof score);
console.log(typeof isPassed);
console.log(typeof country);