// for each is array method
//it iterates once for each element in array
//value, index, array is a fixed position to get output
arr = [1,2,3,4,5];
arr.forEach((value, index, array) => 
    console.log('Index:', index, 'value:', value, 'array:', array)
);
