arr=[1,2,3,4,5]

//using reduce
sum=arr.reduce((a,b)=>a+b);
console.log(sum)

//using for loop
// sum=0;
// for(i=0;i<arr.length;i++){
//     sum+=arr[i]
// }
// console.log(sum)