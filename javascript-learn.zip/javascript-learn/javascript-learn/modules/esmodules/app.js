import {add, sub} from './math.js';
import mul from './math.js'

console.log(add(2,3));
console.log(sub(4,2));
console.log(mul(2,3));