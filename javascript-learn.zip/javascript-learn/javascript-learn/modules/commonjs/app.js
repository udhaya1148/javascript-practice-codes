// Import the module
const math = require('./math');

console.log(math.add(5, 3));
console.log(math.sub(10, 4));
