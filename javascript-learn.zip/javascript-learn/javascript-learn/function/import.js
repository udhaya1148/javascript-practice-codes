let value = require("./export.js")

console.log(value.add(2,3))