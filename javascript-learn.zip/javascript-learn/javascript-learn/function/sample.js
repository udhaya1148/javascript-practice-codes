person={
    name:'kumar',
    age:23,
    greet(){
        console.log(this.name)
    }
}
person.greet()
