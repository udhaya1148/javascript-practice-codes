//How do you delete the age property from the object person?
let person ={
    name:'kumar',
    age:25,
}
delete person.age
console.log(person)