let person ={
    name:'kumar',
    age:25
}
console.log(Object.keys(person)) // print only keys as array
console.log(Object.values(person)) //print only values as array
console.log(Object.entries(person)) //print key and value as array