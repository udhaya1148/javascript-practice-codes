//How do you create an object with keys name as "kumar" and age as 25?
let person ={
    name:'kumar',
    age:25
}
console.log(person)