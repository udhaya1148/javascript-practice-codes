//How do you add a new property city with value "Chennai" to this object?
let person ={
    name:'kumar',
    age:25,
}
person.city='Chennai';
console.log(person)