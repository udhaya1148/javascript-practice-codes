//How do you access the value of name using dot notation and bracket notation?
let person ={
    name:'kumar',
    age:25
}
console.log(person.name) // dot notation
console.log(person['name'])// square bracket notation