"use strict";
function show() {
  console.log(this);
}
show();
