let person={
  name:"kumar",
  age:23,
  city:"cbe",
  display(){
    console.log(this)
  }
}

person.display()