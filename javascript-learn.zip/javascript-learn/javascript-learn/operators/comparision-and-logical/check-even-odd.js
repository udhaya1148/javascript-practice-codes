//Check if a number is even or odd. Use % operator

let num = 5;
if(num % 2 == 0){
    console.log('even');
}
else{
    console.log('odd');
}