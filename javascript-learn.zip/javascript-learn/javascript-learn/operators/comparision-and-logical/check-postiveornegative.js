//Check if a number is positive, negative, or zero.
num=0
if(num > 0){
    console.log('num is positive');
}
else if(num < 0){
    console.log('num is negative');
}
else if(num == 0){
    console.log('num is zero');
}