//Use the ternary operator to check if a person is adult (>=18) or minor.

let age = 18;
let check = (age>=18)?'person is adult':'person is minor';
console.log(check)
