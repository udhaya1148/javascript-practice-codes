//Write a program to swap two numbers without using a third variable.
let a=5;
let b=6;

a=a+b;   //a=5+6=11  a=11   
b=a-b;   //b=11-6    b=5
a=a-b;  //a=11-5     a=6
console.log(a,b) // a=6,b=5