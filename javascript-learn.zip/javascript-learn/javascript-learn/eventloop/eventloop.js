console.log('start');
setTimeout(function() {
  console.log('5 sec')
}, 5000);
console.log('end')