num = -1 

if(num == 0){ 

  console.log('zero') 

   

} 

else if(num > 0){ 

  console.log('positive') 

} 

else if(num < 0){ 

  console.log('negative') 

} 

else{ 

  console.log('not a number') 

} 