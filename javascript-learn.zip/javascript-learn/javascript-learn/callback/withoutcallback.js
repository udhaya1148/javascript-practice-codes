function fetchData() {
    setTimeout(() => {
        console.log("Data fetched!");
        // callback();
    }, 2000);
}

function processData() {
    console.log("Processing data...");
}

fetchData();
processData()
