## 13-10-2025 -  Functions 

- Function declaration
- Function expressions
- Arrow functions
- Default parameters

## 14-10-2025 - Scope & Hoisting

## 15-10-2025
- closure
- ES6 Features

## 16-10-2025
- Dom Manipulation
- Events
- Error handling

## 17-10-2025
- Modules
- Event loop