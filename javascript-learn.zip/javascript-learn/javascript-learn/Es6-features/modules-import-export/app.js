import {add, sub} from './math.js'

console.log(add(2,3));
console.log(sub(4,1));