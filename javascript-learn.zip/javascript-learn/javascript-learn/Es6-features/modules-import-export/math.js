const add = (a,b) => a+b;
const sub = (a,b) => a-b;

export {add, sub};

