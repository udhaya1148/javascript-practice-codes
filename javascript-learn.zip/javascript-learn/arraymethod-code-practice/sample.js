//Given an array of strings ["apple", "banana", "grapes"], use forEach() to print each fruit in uppercase.

fruits = ["apple", "banana", "grapes"]

fruits.forEach((fruit)=> console.log(fruit.toUpperCase()))
